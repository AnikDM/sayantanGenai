import React from 'react';
import '../stylesheet/Navbar.css';
import { Link} from 'react-router-dom';
import { login } from '../pages/CartState';


function Navbar() {
  
  return (
    <>
    <nav className="navbar">
      <div className="logo">
        <img src="/path-to-your-logo.png" alt="Company Logo" />
      </div>
      <ul className="nav-links">
        <li className="nav-item"><Link to="/home">Home</Link></li>
        <li className="nav-item"><Link to="/products">Products</Link></li>
   
        <li className="nav-item"><Link to="/deal">Deals</Link></li>
      </ul>
      <div className="search-bar">
        <input type="text" placeholder="Search products" />
        <button type="submit">Search</button>
      </div>
      <div className="user-actions">
        <Link to="/cart">Cart</Link>
        <Link to="/logout">Logout</Link>
      </div>
    </nav>
    </>
  );
}

export default Navbar;
