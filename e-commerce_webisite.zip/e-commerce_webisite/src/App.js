import './App.css';
import LoginPage from './pages/LoginPage';
import ProductPage from './pages/ProductPage';
import RegisterPage from './pages/RegisterPage';
import Cart from './pages/Cart';
import { BrowserRouter, Routes, Route, Router } from 'react-router-dom';
import Navbar from './components/Navbar';
import LandingPage from './pages/LandingPage';
import { RecoilRoot, useRecoilState, useRecoilValue } from 'recoil';
import { useEffect, useState } from 'react';
import axios from 'axios';
import CheckoutPage from './pages/CheckoutPage';
import Payment from './pages/PaymentPage'
import PaymentPage from './pages/PaymentPage';
import DealPage from './pages/DealPage';
import { login } from './pages/CartState';
import LogoutPage from './pages/LogoutPage';
// const [showNav, setShowNav]= useState(false);

function App() {
  const log = useRecoilValue(login);
  console.log(log)
  return (
    <BrowserRouter>
    {log===true?<Navbar/>:<></>}
      <Routes>
        <Route path="/" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />
        <Route path="/products" element={<ProductPage />} />
        <Route path="/deal" element={<DealPage />} />
        <Route path="/cart" element={<Cart />} />
        <Route path="/home" element={<LandingPage />} />
        <Route path="/checkout" element={<CheckoutPage />} />
        <Route path="/payment" element={<PaymentPage />} />
        <Route path="/logout" element={<LogoutPage />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
