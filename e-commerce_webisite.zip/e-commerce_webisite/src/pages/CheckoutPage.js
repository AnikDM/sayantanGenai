import React, { useState } from "react";
import "../stylesheet/CheckoutPage.css";
import { cartState } from "./CartState";
import { useRecoilValue } from "recoil";
import { Link } from "react-router-dom";

function CheckoutPage() {
  const cartItems = useRecoilValue(cartState);
  
  const [shippingInfo, setShippingInfo] = useState({
    name: "",
    address: "",
    phoneNumber: "",
    city: "",
    pinCode: "",
    // Add more fields as needed
  });

  const [errors, setErrors] = useState({
    phoneNumber: "",
    pinCode: "",
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    let newErrors = { ...errors };

    // Validation for phone number
    if (name === "phoneNumber") {
      const isValidPhoneNumber = /^\d{10}$/.test(value);
      newErrors.phoneNumber = isValidPhoneNumber ? "" : "Invalid phone number";
    }

    // Validation for pin code
    if (name === "pinCode") {
      const isValidPinCode = /^\d{6}$/.test(value);
      newErrors.pinCode = isValidPinCode ? "" : "Invalid pin code";
    }

    setErrors(newErrors);

    setShippingInfo({
      ...shippingInfo,
      [name]: value,
    });
  };

  const handlePlaceOrder = (e) => {
    e.preventDefault();

    // Check if there are any errors before proceeding
    if (errors.phoneNumber || errors.pinCode) {
      alert("Please fix the validation errors before making payment.");
      return;
    }

    // Add logic to handle placing the order
 

    // Clear the cart or perform other actions
  };

  return (
    <div className="checkout-container">
      <h2>Checkout</h2>
      <div className="order-summary">
        <h3>Order Summary</h3>
        <ul>
          {cartItems.map((item) => (
            <li key={item.product.id}>
              {item.product.title} - ${item.product.price}
            </li>
          ))}
        </ul>
      </div>
      <div className="shipping-form">
        <h3>Shipping Information</h3>
        <form onSubmit={handlePlaceOrder}>
          <label>
            Name:
            <input
              type="text"
              name="name"
              value={shippingInfo.name}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Address:
            <input
              type="text"
              name="address"
              value={shippingInfo.address}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Phone Number:
            <input
              type="tel"
              name="phoneNumber"
              value={shippingInfo.phoneNumber}
              onChange={handleInputChange}
              required
            />
            {errors.phoneNumber && <p className="error-message">{errors.phoneNumber}</p>}
          </label>
          <label>
            City:
            <input
              type="text"
              name="city"
              value={shippingInfo.city}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Pin Code:
            <input
              type="text"
              name="pinCode"
              value={shippingInfo.pinCode}
              onChange={handleInputChange}
              required
            />
            {errors.pinCode && <p className="error-message">{errors.pinCode}</p>}
          </label>
          <button type="submit"><Link to={{ pathname: "/payment"}}>Proceed To Payments</Link></button>
        </form>
      </div>
    </div>
  );
}

export default CheckoutPage;
