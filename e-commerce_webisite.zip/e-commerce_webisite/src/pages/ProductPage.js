import React, { useState, useEffect } from "react";
import axios from "axios";
import "../stylesheet/ProductPage.css";
import { useRecoilState, useRecoilValue, useSetRecoilState } from "recoil";
import { cartState, productCounterState } from "./CartState";

const ProductPage = () => {
  const [cart, setCart] = useRecoilState(cartState);
  const [productCounter, setProductCounter] =
    useRecoilState(productCounterState);
  const [products, setProducts] = useState([]);
  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products")
      .then((response) => {
        setProducts(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);
  function truncate(text) {
    return text.slice(0, 20) + "...";
  }
  const addToCart = (product) => {
    console.log(cart);
    console.log(product.id);
    // Check if the product is already in the cart
    const existingItem = cart.findIndex(
      (item) => item.product.id === product.id
    );
    console.log(product);
    console.log(existingItem);
    if (existingItem + 1) {
      console.log("iside if");
      // If the product exists in the cart, increase its quantity
      const updatedCart = cart.map((item) =>
        item.product.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : { ...item, quantity: item.quantity }
      );
      console.log(updatedCart);
      setCart(updatedCart);
    } else {
      console.log("inside else");
      // If the product is not in the cart, add it with a quantity of 1
      setCart([...cart, { product, quantity: 1 }]);
    }
  };

  return (
    <div className="product-grid">
      {products.map((product) => (
        <div key={product.id} className="product-page-card">
          <img src={product.image} alt={product.title} />
          <h3>
            {product.title.length > 30
              ? truncate(product.title)
              : product.title}
          </h3>
          <p>${product.price}</p>
          <span>
            <span className="counter">
              {cart.findIndex((item) => item.product.id === product.id) != -1
                ? cart[cart.findIndex((item) => item.product.id === product.id)].quantity
                : ""}
            </span>
          </span>
          <button
            className="add-to-cart-button"
            onClick={() => addToCart(product)}
          >
            Add to cart
          </button>
        </div>
      ))}
    </div>
  );
};

export default ProductPage;
