import { atom } from 'recoil';

export const cartState = atom({

  key: 'cartState',

  default: [], // Initialize cart as an empty array

});

export const productCounterState = atom({

  key: 'productCounterState',

  default: {}, // Initialize cart as an empty array

});

export const login = atom({

  key: 'login',

  default: false, // Initialize cart as an empty array

});
export const orderPlaced = atom(
  {

  key: 'orderPlaced',

  default: false, // Initialize cart as an empty array

});