import React, { useEffect, useState } from "react";
import { useRecoilValue, useRecoilState } from "recoil";
import { Link } from "react-router-dom";
import { cartState } from "./CartState";
import "../stylesheet/CartPage.css";

function Cart() {
  // Get the cart contents from Recoil
  const cart = useRecoilValue(cartState);
  const [cartItems, setCartItems] = useRecoilState(cartState);
  console.log(cart);
  const handleAddToCart = (product) => {
    // Add the product to the cart if it is not already there
    const updatedCart = [...cartItems];
    const productIndex = updatedCart.findIndex(
      (item) => item.id === product.id
    );
    if (productIndex === -1) {
      updatedCart.push({
        ...product,
        quantity: 1,
      });
    } else {
      updatedCart[productIndex].quantity += 1;
    }

    // Update the cart state
    setCartItems(updatedCart);
  };
  const removeFromCart = (productId) => {
    // Remove the selected product from the cart
    const updatedCart = cartItems.filter(
      (item) => item.product.id !== productId
    );
    setCartItems(updatedCart);
  };

  const increaseQuantity = (productId) => {
    // Increase the quantity of a product in the cart
    const updatedCart = cartItems.map((item) => {
      console.log(item);
      if (item.product.id === productId) {
        return {
          ...item,
          quantity: item.quantity + 1,
        };
      }
      return item;
    });
    console.log(updatedCart);
    setCartItems(updatedCart);
  };

  const decreaseQuantity = (productId) => {
    // Decrease the quantity of a product in the cart
    const updatedCart = cartItems.map((item) => {
      if (item.product.id === productId && item.quantity > 1) {
        return {
          ...item,
          quantity: item.quantity - 1,
        };
      }
      return item;
    });
    setCartItems(updatedCart);
  };

  // Calculate the total cart price
  const totalCartPrice = cart.reduce(
    (total, item) => total + item.product.price * item.quantity,
    0
  );


  const totalItemCount = cart.reduce((total, item) => total + item.quantity, 0);

  const checkout = () => {
    // Your checkout logic here
  };

  return (
    <div className="cart-container">
      <h1>Your Shopping Cart</h1>
      <div className="cart-items">
        <div className="cart-card-container">
          {cart.length === 0 ? (
            <p>Your cart is empty.</p>
          ) : (
            cart.map((item) => (
              <div className="cart-card" key={item.product.id}>
                <img
                  src={item.product.image}
                  height={"100px"}
                  alt={item.product.title}
                  className="cart-card-image"
                />
                <div className="cart-card-details">
                  <h3>{item.product.title}</h3>
                  <p>${item.product.price}</p>
                  <div className="quantity-control">
                    <button
                      className="quantity-button"
                      onClick={() => decreaseQuantity(item.product.id)}
                    >
                      -
                    </button>
                    <span className="quantity">{item.quantity}</span>
                    <button
                      className="quantity-button"
                      onClick={() => increaseQuantity(item.product.id)}
                    >
                      +
                    </button>
                  </div>
                  <button
                    className="remove-from-cart-button"
                    onClick={() => removeFromCart(item.product.id)}
                  >
                    Remove from Cart
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
      
      {cart.length > 0 && (
        <div className="total-cart-section">
          <div className="total-cart-price">
          <p>Total Items: {totalItemCount}</p>
          <div className="priceField">
            <p>Total Cart Price:</p>
            <h3>${totalCartPrice.toFixed(2)}</h3>
            </div>
            
          </div>
         
          <button className="checkout-button" onClick={checkout}>
            <Link to={{ pathname: "/checkout"}}>Proceed To Checkout</Link>
          </button>
          
        </div>
      )}
    </div>
  );
}


export default Cart;
