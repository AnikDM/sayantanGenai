import React, { useState } from "react";
import "../stylesheet/PaymentPage.css";
import { cartState,orderPlaced } from "./CartState";
import { useRecoilValue,useRecoilState   } from "recoil";
import { useNavigate } from "react-router-dom";

function PaymentPage() {
  const navigate = useNavigate();
  const [cartItems,setCartItems] = useRecoilState(cartState);
  const [,setOrder] = useRecoilState(orderPlaced);
  const [paymentInfo, setPaymentInfo] = useState({
    cardNumber: "",
    expirationDate: "",
    cvv: "",
    // Add more fields as needed
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setPaymentInfo({
      ...paymentInfo,
      [name]: value,
    });
  };

  const handleMakePayment = (e) => {
    e.preventDefault();

    // Add logic for payment processing here
    alert("Payment successful!");
    navigate('/home', { replace: true });
    setOrder(true);
    // Clear the cart or perform other actions
  };

  return (
    <div className="payment-container">
      <h2>Payment</h2>
      <div className="order-summary">
        <h3>Order Summary</h3>
        <ul>
          {cartItems.map((item) => (
            <li key={item.product.id}>
              {item.product.title} - ${item.product.price}
            </li>
          ))}
        </ul>
      </div>
      <div className="payment-form">
        <h3>Payment Information</h3>
        <form onSubmit={handleMakePayment}>
          <label>
            Card Number:
            <input
              type="text"
              name="cardNumber"
              value={paymentInfo.cardNumber}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            Expiration Date:
            <input
              type="text"
              name="expirationDate"
              value={paymentInfo.expirationDate}
              onChange={handleInputChange}
              required
            />
          </label>
          <label>
            CVV:
            <input
              type="text"
              name="cvv"
              value={paymentInfo.cvv}
              onChange={handleInputChange}
              required
            />
          </label>
          <button type="submit">Make Payment</button>
        </form>
      </div>
    </div>
  );
}

export default PaymentPage;
