import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../stylesheet/DealPage.css';

function DealPage() {
  const [dealProduct, setDealProduct] = useState(null);

  useEffect(() => {
    // Fetch one product from the FakeStore API as the deal of the day
    axios
      .get('https://fakestoreapi.com/products/1') // Change the product ID as needed
      .then((response) => {
        setDealProduct(response.data);
        console.log(response.data);
        
      })
      .catch((error) => {
        console.error('Error fetching deal product:', error);
      });
  }, []);

  return (
    <div className="deal-page">
      <section className="deal-of-the-day">
        <h1 className="heading">Deal of the Day</h1>
        {dealProduct && (
          <div className="deal-product">
            <img src={dealProduct.image} alt={dealProduct.title} />
            <div className="deal-details">
              <h3><h4>Product Name:</h4>{dealProduct.title}</h3>
             <p><h4>Product Description:</h4> {dealProduct.description}</p>
              <p>Price: ${dealProduct.price}</p>
              {/* Add more product details as needed */}
            </div>
          </div>
        )}
      </section>
    </div>
  );
}

export default DealPage;
