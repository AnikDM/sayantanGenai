
import '../stylesheet/LandingPage.css';
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { orderPlaced,cartState } from './CartState';
import { useRecoilState, useRecoilValue } from 'recoil';

function LandingPage() {
  const [featuredProducts, setFeaturedProducts] = useState([]);
  const [companyName] = useState("XYZ E-commerce Site"); // Updated company name
  const order=useRecoilValue(orderPlaced);
  const [cart,setCart]=useRecoilState(cartState);
  useEffect(() => {
    // Fetch two featured products from the FakeStore API
    axios
      .get('https://fakestoreapi.com/products?limit=4') // Limit to 4 products
      .then((response) => {
        setFeaturedProducts(response.data);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);

  return (
    <div className="landing-page">
      {/* Header Title */}
      {/* Updated header title */}
      
      {/* Featured Products */}
      <section className="featured-products">
        <h1 className='heading'> Welcome to the XYZ site Home Page</h1>
        
        {order===true?
          (
          cart.map((item)=><><span>Preparing for Dispatch...</span><span>{item.product.title}</span><br/></>
        )):<></>}
        
        <h2>Featured Products</h2>
        <div className="product-grid">
          {featuredProducts.map((product) => (
            <div key={product.id} className="product-card">
              <img src={product.image} alt={product.title} />
              <h3>{product.title}</h3>
              <p>Price: ${product.price}</p>
              {/* Add more product details as needed */}
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

export default LandingPage;


