import React from 'react'
import { login } from './CartState'
import { useRecoilState } from 'recoil'
import { Link } from 'react-router-dom'

const LogoutPage = () => {
    const [,setLogin]=useRecoilState(login)
    setLogin(false);
  return (
    <div>
      You have been succesfully logged out
      <button><Link to={'/'}>Login Again</Link></button>
    </div>
  )
}

export default LogoutPage
