

import React, { useState } from 'react';
import { Link,useNavigate} from 'react-router-dom';
import '../stylesheet/LoginPage.css'; // Import the CSS file for styling
import { login } from './CartState';
import { useRecoilState } from 'recoil';

function LoginPage() {
  const navigate = useNavigate();
  const [,setLogin]=useRecoilState(login);
  const [formData, setFormData] = useState({
    username: '',
    password: '',
    otp: '', // New state for OTP
  });

  const [validationErrors, setValidationErrors] = useState({});
  const [generatedOTP, setGeneratedOTP] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const generateRandomOTP = () => {
    // Generate a random 4-digit OTP
    const randomOTP = Math.floor(1000 + Math.random() * 9000);
    console.log('Generated OTP For Login:', randomOTP);
    setGeneratedOTP(randomOTP.toString());
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate the form data
    const errors = {};
    if (!formData.username) {
      errors.username = 'Username is required.';
    }

    if (!formData.password) {
      errors.password = 'Password is required.';
    }

    if (!formData.otp || formData.otp !== generatedOTP) {
      errors.otp = 'Invalid OTP.';
    }

    // If there are any errors, display them to the user
    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      alert('Login failed. Please check your credentials and OTP.');
      return;
    }

    // If there are no errors, submit the login form with OTP
    // You can replace this with your login logic with OTP
    alert('Login successful!');
    setLogin(true);
    navigate('/home', { replace: true });
  };

  const handleForgotPassword = () => {
    // Implement your "Forgot Password" logic here
    console.log('Forgot Password clicked');
  };

  const handleChangePassword = () => {
    // Implement your "Change Password" logic here
    console.log('Change Password clicked');
  };

  const handleSendOTP = () => {
    generateRandomOTP(); // Generate and display OTP
  };

  const displayValidationErrors = () => {
    return Object.keys(validationErrors).map((errorField) => {
      const errorMessage = validationErrors[errorField];

      return (
        <p key={errorField} className="validation-error">
          {errorMessage}
        </p>
      );
    });
  };

  return (
    <div className="login-container">
      <h2>Login</h2>

      <form onSubmit={handleSubmit}>
        <div className="input-group">
          <label>Username:</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
          />
        </div>

        <div className="input-group">
          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
          />
        </div>

        <div className="input-group">
          <label>OTP:</label>
          <input
            type="text"
            name="otp"
            value={formData.otp}
            onChange={handleChange}
          />
          <button type="button" onClick={handleSendOTP}>
            Send OTP
          </button>
        </div>

        {displayValidationErrors()}

        <button type="submit">Login</button>
      </form>

      <div className="password-options">
        <button onClick={handleForgotPassword}>Forgot Password</button>
        <button onClick={handleChangePassword}>Change Password</button>
      </div>

      <p className="register-link">
        Don't have an account? <Link to="/register">Register</Link>
      </p>
    </div>
  );
}

export default LoginPage;
