import React, { useState } from "react";
import "../stylesheet/CheckoutPage.css";
import { cartState } from "./CartState";
import { useRecoilValue } from "recoil";
function CheckoutPage() {
  const cartItems = useRecoilValue(cartState);
  console.log(cartItems);
  const [shippingInfo, setShippingInfo] = useState({
    name: "",
    address: "",
    city: "",
    // Add more fields as needed
  });
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setShippingInfo({
      ...shippingInfo,
      [name]: value,
    });
  };
  const handlePlaceOrder = (e) => {
    e.preventDefault(); // Prevents the default form submission behavior
    // Add logic for form validation if needed
    // Add logic to handle placing the order
    alert('order placed')
    // Clear the cart or perform other actions
  };
  return (
    <div className="checkout-container">
      <h2>Checkout</h2>
      <div className="order-summary">
        <h3>Order Summary</h3>
        <ul>
          {cartItems.map((item) => (
            <li key={item.product.id}>
              {item.product.title} - ${item.product.price}
            </li>
          ))}
        </ul>
      </div>
      <div className="shipping-form">
        <h3>Shipping Information</h3>
        <form onSubmit={handlePlaceOrder}>
          <label>
            Name:
            <input
              type="text"
              name="name"
              value={shippingInfo.name}
              onChange={handleInputChange}
              required // Add required attribute for form validation
            />
          </label>
          {/* Add more input fields for address, city, etc. */}
          <button type="submit">Place Order</button>
        </form>
      </div>
    </div>
  );
}
export default CheckoutPage;
