// // src/LoginPage.js

// import React, { useState } from 'react';
// import { Link } from 'react-router-dom';

// import '../stylesheet/LoginPage.css'; // Import the CSS file for styling

 

// function LoginPage() {

//   const [formData, setFormData] = useState({

//     username: '',

//     password: '',

//   });

 

//   const handleChange = (e) => {

//     const { name, value } = e.target;

//     setFormData({

//       ...formData,

//       [name]: value,

//     });

//   };

 

//   const handleSubmit = (e) => {

//     e.preventDefault();

//     // You can replace this with your login logic

//     console.log('Login data submitted:', formData);

//   };

 

//   const handleForgotPassword = () => {

//     // Implement your "Forgot Password" logic here

//     console.log('Forgot Password clicked');

//   };

 

//   const handleChangePassword = () => {

//     // Implement your "Change Password" logic here

//     console.log('Change Password clicked');

//   };

 

//   return (

//     <div className="login-container">

//       <h2>Login</h2>

//       <form onSubmit={handleSubmit}>

//         <div className="input-group">

//           <label>Username:</label>

//           <input

//             type="text"

//             name="username"

//             value={formData.username}

//             onChange={handleChange}

//           />

//         </div>

//         <div className="input-group">

//           <label>Password:</label>

//           <input

//             type="password"

//             name="password"

//             value={formData.password}

//             onChange={handleChange}

//           />

//         </div>

//         <button type="submit">Login</button>

//       </form>

//       <div className="password-options">

//         <button onClick={handleForgotPassword}>Forgot Password</button>

//       <button onClick={handleChangePassword}>Change Password</button> 
//       </div>
//       {/* <p className='register-link'>
//         Don't have an account? <Link to ="/register">Register</Link>
//       </p> */}
//      <p className="register-link">
//         Don't have an account? <Link to="/register">Register</Link>
//       </p>
      
//     </div>

//   );

// }

// export default LoginPage;


import React, { useState } from 'react';
import { Link } from 'react-router-dom';

import '../stylesheet/LoginPage.css'; // Import the CSS file for styling

function LoginPage() {

  const [formData, setFormData] = useState({
    username: '',
    password: '',
  });

  const [validationErrors, setValidationErrors] = useState({});

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData({
      ...formData,
      [name]: value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();

    // Validate the form data
    const errors = {};
    if (!formData.username) {
      errors.username = 'Username is required.';
    }

    if (!formData.password) {
      errors.password = 'Password is required.';
    }

    // If there are any errors, display them to the user
    if (Object.keys(errors).length > 0) {
      setValidationErrors(errors);
      return;
    }

    // If there are no errors, submit the login form
    // You can replace this with your login logic
    console.log('Login data submitted:', formData);
  };

  const handleForgotPassword = () => {
    // Implement your "Forgot Password" logic here
    console.log('Forgot Password clicked');
  };

  const handleChangePassword = () => {
    // Implement your "Change Password" logic here
    console.log('Change Password clicked');
  };

  const displayValidationErrors = () => {
    return Object.keys(validationErrors).map((errorField) => {
      const errorMessage = validationErrors[errorField];

      return (
        <p key={errorField} className="validation-error">
          {errorMessage}
        </p>
      );
    });
  };

  return (
    <div className="login-container">
      <h2>Login</h2>

      <form onSubmit={handleSubmit}>
        <div className="input-group">
          <label>Username:</label>
          <input
            type="text"
            name="username"
            value={formData.username}
            onChange={handleChange}
          />
        </div>

        <div className="input-group">
          <label>Password:</label>
          <input
            type="password"
            name="password"
            value={formData.password}
            onChange={handleChange}
          />
        </div>

        {displayValidationErrors()}

        <button type="submit">Login</button>
      </form>

      <div className="password-options">
        <button onClick={handleForgotPassword}>Forgot Password</button>
        <button onClick={handleChangePassword}>Change Password</button>
      </div>

      <p className="register-link">
        Don't have an account? <Link to="/register">Register</Link>
      </p>
    </div>
  );
}

export default LoginPage;
