import './App.css';
import LoginPage from './pages/LoginPage';
import ProductPage from './pages/ProductPage';
import RegisterPage from './pages/RegisterPage';
import Cart from './pages/Cart';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import LandingPage from './pages/LandingPage';
import { RecoilRoot } from 'recoil';
import { useEffect, useState } from 'react';
import axios from 'axios';
import CheckoutPage from './pages/CheckoutPage';



function App() {
  return (
    <div>
      <RecoilRoot>
        <BrowserRouter>
          <Navbar />
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/products" element={<ProductPage/>} />
            <Route path="/cart" element={<Cart/>} />
            <Route path="/" element={<LandingPage />}  exact/>
            <Route path="/checkout" element={<CheckoutPage />}  />
          </Routes>
        </BrowserRouter>
      </RecoilRoot>

    </div>
  );
}

export default App;
