import React from 'react';
import '../stylesheet/Navbar.css'

function Navbar() {
  return (
    <nav className="navbar">
      <div className="logo">
        <img src="/path-to-your-logo.png" alt="Company Logo" />
      </div>
      <ul className="nav-links">
        <li className="nav-item"><a href="/home">Home</a></li>
        <li className="nav-item"><a href="/products">Products</a></li>
        <li className="nav-item"><a href="/categories">Categories</a></li>
        <li className="nav-item"><a href="/deals">Deals</a></li>
      </ul>
      <div className="search-bar">
        <input type="text" placeholder="Search products" />
        <button type="submit">Search</button>
      </div>
      <div className="user-actions">
        <a href="/cart">Cart</a>
        <a href="/login">Login</a>
      </div>
    </nav>
  );
}

export default Navbar;
