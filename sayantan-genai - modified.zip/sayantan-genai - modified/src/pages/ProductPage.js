import React, { useState, useEffect } from "react";
import axios from "axios";
import "../stylesheet/ProductPage.css";
import { useRecoilState, useRecoilValue, useSetRecoilState } from "recoil";
import { cartState, productCounterState } from "./CartState";

const ProductPage = ({ addToCart }) => {
  const [cart, setCart] = useRecoilState(cartState);
  const [productCounter, setProductCounter] =
    useRecoilState(productCounterState);
  const [products, setProducts] = useState([]);
  useEffect(() => {
    axios
      .get("https://fakestoreapi.com/products")
      .then((response) => {
        setProducts(response.data);
      })
      .catch((error) => {
        console.error("Error fetching data:", error);
      });
  }, []);
  function truncate(text) {
    return text.slice(0, 20) + "...";
  }
  function addToCart(prod) 
  {
      setCart(cart.length===0?[prod]:[...cart,prod]);

    console.log(cart);
    setProductCounter((prevCounter) => ({
      ...prevCounter,
      [prod.id]: (prevCounter[prod.id] || 0) + 1,
    }));
  }
  return (
    <div className="product-grid">
      {products.map((product) => (
        <div key={product.id} className="product-page-card">
          <img src={product.image} alt={product.title} />
          <h3>
            {product.title.length > 30
              ? truncate(product.title)
              : product.title}
          </h3>
          <p>${product.price}</p>
          <span className="counter">{productCounter[product.id]}</span>
          <button class="add-to-cart-button" onClick={() => addToCart(product)}>
            Add to cart
          </button>
        </div>
      ))}
    </div>
  );
};

export default ProductPage;
