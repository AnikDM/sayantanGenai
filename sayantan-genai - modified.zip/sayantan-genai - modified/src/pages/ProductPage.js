
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../stylesheet/ProductPage.css';
import { useRecoilState, useSetRecoilState } from 'recoil';
import { cartState } from './CartState';

const ProductPage = ({addToCart}) => {
  const [products, setProducts] = useState([]);
  useEffect(() => {
    axios.get('https://fakestoreapi.com/products')
      .then((response) => {
        setProducts(response.data);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);
  function truncate(text){
    return text.slice(0,20)+"...";
  }
  return (
    <div className="product-grid">
      {products.map((product) => (
        <div key={product.id} className="product-page-card">
          <img src={product.image} alt={product.title} />
          <h3>{product.title.length>30?truncate(product.title):product.title}</h3>
          <p>${product.price}</p>
          <button onClick={() => addToCart(product)}>Add to Cart</button>
        </div>
      ))}
    </div>
  );
};

export default ProductPage;

