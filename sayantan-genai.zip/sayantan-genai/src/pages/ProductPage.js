
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import '../stylesheet/ProductPage.css'; // Import your CSS file
import { cartState } from './Cartstate';
import { useRecoilState } from 'recoil';

const ProductPage = () => {
  const [products, setProducts] = useState([]);
  const [cart, setCart] = useRecoilState(cartState);

  useEffect(() => {
    axios.get('https://fakestoreapi.com/products')
      .then((response) => {
        setProducts(response.data);
      })
      .catch((error) => {
        console.error('Error fetching data:', error);
      });
  }, []);

  // Function to handle adding a product to the cart
  // const handleAddToCart = (product) => {
  //   // You can implement the cart logic here
  //   console.log(`Added ${product.title} to the cart`);
  // }

  const addToCart = (product) => {
    // Check if the product is already in the cart
    const existingItem = cart.findIndex((item) => item.id === product.id);
    console.log(product);
    console.log(existingItem);
    if (existingItem) {
      // If the product exists in the cart, increase its quantity
      const updatedCart = cart.map((item) =>
        item.id === product.id
          ? { ...item, quantity: item.quantity + 1 }
          : item
      );
      setCart(updatedCart);
    } else {
      console.log("inside else");
      // If the product is not in the cart, add it with a quantity of 1
      setCart([...cart,{...product,quantity: 1}]);
    }
    setCart([{product,quantity:1}]);
  };


  return (
    <div className="product-grid">
      {products.map((product) => (
        <div key={product.id} className="product-card">
          <img src={product.image} alt={product.title} />
          <h3>{product.title}</h3>
          <p>${product.price}</p>
          {/* Add to Cart Button */}
          <button onClick={() => addToCart(product)}>Add to Cart</button>
        </div>
      ))}
    </div>
  );
};

export default ProductPage;

