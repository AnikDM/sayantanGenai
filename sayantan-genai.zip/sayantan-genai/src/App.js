import './App.css';
import LoginPage from './pages/LoginPage';
import ProductPage from './pages/ProductPage';
import RegisterPage from './pages/RegisterPage';
import Cart from './pages/Cart';
import { cartState } from './pages/Cartstate';
// import { CartProvider } from './pages/CartContext';
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import LandingPage from './pages/LandingPage';
import { RecoilRoot } from 'recoil';


function App() {
  return (
    <div>
      <RecoilRoot>
        <BrowserRouter>
          <Navbar />
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route path="/register" element={<RegisterPage />} />
            <Route path="/products" element={<ProductPage />} />
            <Route path="/cart" element={<Cart />} />
            <Route path="/" element={<LandingPage />} />
          </Routes>
        </BrowserRouter>
      </RecoilRoot>

    </div>
  );
}

export default App;
